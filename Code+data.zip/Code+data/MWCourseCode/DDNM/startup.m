

clear
set(0,'DefaultFigureWindowStyle','docked')
figure(1);clf;figure(2);clf
addpath('../../Utilities')
addpath('../../Data'); 
addpath('../../Data/EEG-data+utilities')


