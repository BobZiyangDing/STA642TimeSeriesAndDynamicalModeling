% MW startup file
clear

set(0,'DefaultFigureWindowStyle','docked') 
addpath('../../Utilities')
addpath('./AR_matlab_utilities')
addpath('../../Data')
