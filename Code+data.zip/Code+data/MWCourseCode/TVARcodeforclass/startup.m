
%%% Students will need to customize this to make sure the paths to data and utilities are correct

clear
set(0,'DefaultFigureWindowStyle','docked')

addpath('../../Utilities')
addpath('../../Data'); 
addpath('../AR/AR_matlab_utilities'); 
addpath('./TVARutilities')

