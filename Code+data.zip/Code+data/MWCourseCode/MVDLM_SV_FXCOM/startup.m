

clear
set(0,'DefaultFigureWindowStyle','docked')
%setfigc
addpath('../../Utilities')
addpath('../../Data'); 
addpath('../../Data/EEG-data+utilities')

